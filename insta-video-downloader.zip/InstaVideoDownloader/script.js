function downloadVideo() {
  const url = document.getElementById('urlInput').value;
  
  if (url === '') {
    alert('Please enter a valid Instagram URL!');
    return;
  }

  document.getElementById('result').innerHTML = `
    <p>Video download link tayar ho raha hai...</p>
    <a href="${url}" target="_blank">Download Now</a>
  `;
}
body {
  font-family: Arial, sans-serif;
  background-color: #f0f0f5;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  margin: 0;
}

.container {
  text-align: center;
  background: #fff;
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

h1 {
  color: #4c68d7;
}

input {
  width: 80%;
  padding: 10px;
  margin: 20px 0;
  border: 2px solid #4c68d7;
  border-radius: 5px;
}

button {
  background-color: #4c68d7;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

button:hover {
  background-color: #3b50b3;
}

#result {
  margin-top: 20px;
}